export type CategoryType = 'color-illustrations' | 'manga-ink' | 'banners' | 'logos-branding';

export interface CropSettings {
  isCropped: boolean;
  scale?: string; // e.g. 'w-[200%] h-[200%]'
  position?: string; // e.g. 'top-0 left-0' or translate shifts
  customStyles?: Record<string, string | number>;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: CategoryType;
  styleTag: string; // e.g. 'Gótico / Cyberpunk'
  priceEstimate: number;
  description: string;
  imageSrc: string;
  crop?: CropSettings;
  features: string[];
}

export interface CommissionConfig {
  service: CategoryType;
  complexity: 'simple' | 'medium' | 'detailed';
  format: 'digital_only' | 'source_files' | 'commercial_rights';
  customDetails: string;
}
