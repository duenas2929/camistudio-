import { PortfolioItem } from './types';

import imageGrid from './assets/images/image_grid_1781195730007.jpg';
import logosGrid from './assets/images/logos_grid_1781195746706.jpg';
import featuredIllust from './assets/images/featured_illust_1781195709547.jpg';
import maidLineart from './assets/images/maid_lineart_1781195761663.jpg';
import mangaActionPage from './assets/images/manga_action_page_1781194573616.jpg';
import mangaSliceLifePage from './assets/images/manga_slice_life_1781194591318.jpg';
import gamingBannerTech from './assets/images/gaming_banner_tech_1781194614429.jpg';

export const COMPONENT_IMAGE_GRID = imageGrid;
export const COMPONENT_LOGOS_GRID = logosGrid;
export const COMPONENT_FEATURED_ILLUST = featuredIllust;
export const COMPONENT_MAID_LINEART = maidLineart;

// Resolve actual generated image paths based on built artifacts
export const MANGA_ACTION_PAGE = mangaActionPage;
export const MANGA_SLICE_LIFE_PAGE = mangaSliceLifePage;
export const GAMING_BANNER_TECH = gamingBannerTech;

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  // --- ILLUSTRATIONS COLOR ---
  {
    id: 'f-1',
    title: 'Aura Gótica Nocturna',
    category: 'color-illustrations',
    styleTag: 'Gótico / Ilustración Completa',
    priceEstimate: 120,
    description: 'Ilustración digital de alta complejidad con sombreado refinado y efectos cinemáticos de farol místico, tatuajes ornamentales y fondo detallado de ciudad y catedral bajo la luna llena púrpura.',
    imageSrc: COMPONENT_FEATURED_ILLUST,
    features: [
      'Ilustración premium a cuerpo completo/medio',
      'Fondo súper de catedral mística y luna',
      'Accesorios ornamentales complejos',
      'Luces mágicas ambientales con destellos violetas',
      'Archivos listos para impresión en poster'
    ]
  },
  {
    id: 'c-1',
    title: 'Violeta Nocturna',
    category: 'color-illustrations',
    styleTag: 'Cyber-Goth / Retrato',
    priceEstimate: 45,
    description: 'Ilustración tipo retrato de personaje femenino ciber-gótico, con detalles en las joyas góticas de las orejas y cabello negro azabache con reflejos morados.',
    imageSrc: COMPONENT_IMAGE_GRID,
    crop: {
      isCropped: true,
      scale: 'w-[200%] h-[200%]',
      position: 'top-0 left-0'
    },
    features: [
      'Retrato detallado de busto',
      'Accesorios y piercings ciber-góticos detallados',
      'Paleta de color púrpura y sombras suaves',
      'Formatos ideales para foto de perfil de streamer'
    ]
  },
  {
    id: 'c-2',
    title: 'Luz Cálida d\'Otoño',
    category: 'color-illustrations',
    styleTag: 'Cozy Anime / Retrato',
    priceEstimate: 45,
    description: 'Retrato cálido de chica de cabello rubio dorado y ojos azules cristalinos, con una atmósfera reflexiva y relajada que transmite paz y cercanía.',
    imageSrc: COMPONENT_IMAGE_GRID,
    crop: {
      isCropped: true,
      scale: 'w-[200%] h-[200%]',
      position: 'top-0 left-[-100%]'
    },
    features: [
      'Iluminación suave indirecta de sol de tarde',
      'Coloración y texturas sutiles en la piel y el cabello',
      'Fondo natural desenfocado de interiores',
      'Formatos optimizados para redes sociales'
    ]
  },
  {
    id: 'c-3',
    title: 'Pecas y Café',
    category: 'color-illustrations',
    styleTag: 'Casual Moderno',
    priceEstimate: 45,
    description: 'Estudio de retrato de cabello bob castaño oscuro, pecas detalladas y una mirada expresiva con pendientes de estrella dorados.',
    imageSrc: COMPONENT_IMAGE_GRID,
    crop: {
      isCropped: true,
      scale: 'w-[200%] h-[200%]',
      position: 'top-[-100%] left-0'
    },
    features: [
      'Sombreado pictórico semidetallado',
      'Enfoque en expresividad ocular intensa',
      'Fondo neutral ideal para uso multiplataforma',
      'Detalles de accesorios en brillo dorado'
    ]
  },
  {
    id: 'c-4',
    title: 'Carmesí Rebelde',
    category: 'color-illustrations',
    styleTag: 'Punk-Rock Anime',
    priceEstimate: 45,
    description: 'Retrato alternativo con una deslumbrante melena de color rojo encendido, chocker de cuero negro con crucifijos y piercings múltiples.',
    imageSrc: COMPONENT_IMAGE_GRID,
    crop: {
      isCropped: true,
      scale: 'w-[200%] h-[200%]',
      position: 'top-[-100%] left-[-100%]'
    },
    features: [
      'Iluminación dramática de alto contraste (Chiaroscuro)',
      'Accesorios góticos / punk realistas',
      'Paleta audaz de rojos intensos y sombras oscuras',
      'Firma estilizada para mercancía propia'
    ]
  },

  // --- MANGA & INK ---
  {
    id: 'm-1',
    title: 'La Sirvienta Tradicional',
    category: 'manga-ink',
    styleTag: 'Manga / Arte de Línea',
    priceEstimate: 35,
    description: 'Ilustración clásica a tinta digital en blanco y negro, con vestimentas tradicionales de encaje, lazo en el cuello y peinado detallado con trenza.',
    imageSrc: COMPONENT_MAID_LINEART,
    features: [
      'Lineart vectorial súper limpio y fluido',
      'Tramado clásico por achurado místico',
      'Resolución gigante ideal para manga de coloración',
      'Derecho comercial para portadas de libros/mangas'
    ]
  },
  {
    id: 'm-2',
    title: 'Crónicas Shonen',
    category: 'manga-ink',
    styleTag: 'Shonen / Dinámico / Acción',
    priceEstimate: 60,
    description: 'Página completa de manga Shonen con diagramación multi-panel dinámica, tramas mecánicas (screentone), globos de texto e impacto visual increíble.',
    imageSrc: MANGA_ACTION_PAGE,
    features: [
      'Planificación de storyboard y bocetos previos',
      'Diagramación dinámica de hasta 5 paneles',
      'Tinta clásica con líneas cinéticas y de acción',
      'Texturizado con tramas de imprenta japonesas (.half-tone)'
    ]
  },
  {
    id: 'm-3',
    title: 'Silencios Diarios',
    category: 'manga-ink',
    styleTag: 'Shojo / Recuentos de la Vida',
    priceEstimate: 60,
    description: 'Ilustración narrativa de manga Shojo con sombreado de tramas degradadas, atmósfera tierna y pacífica, y close-up emotivo del personaje principal.',
    imageSrc: MANGA_SLICE_LIFE_PAGE,
    features: [
      'Sombreado emocional con degrade de tramas',
      'Enfoque en los sentimientos y luces ambientales suaves',
      'Fondos y vegetación dibujados con esmero',
      'Formato estándar listo para plataforma de webcomics'
    ]
  },

  // --- BANNERS ---
  {
    id: 'b-1',
    title: 'Banner de Transmisión Neon-Cyber',
    category: 'banners',
    styleTag: 'Banner Stream / Twitch',
    priceEstimate: 40,
    description: 'Encabezado profesional optimizado para canales de streaming de videojuegos, estética de cuadrícula de neón púrpura y espacios adaptados para horarios e insignias de redes.',
    imageSrc: GAMING_BANNER_TECH,
    features: [
      'Medidas perfectas para banner de Twitch, YouTube, Kick o Discord',
      'Secciones editables para integrar tu cronograma y tus redes',
      'Iluminación de neón y patrones de interfaz de usuario de ciencia ficción',
      'Incluye versión estática y fuentes de texto para personalización'
    ]
  },

  // --- LOGOS & BRANDING ---
  {
    id: 'l-1',
    title: 'Logo Nocturna Studio',
    category: 'logos-branding',
    styleTag: 'Isologo Gótico Ilustrado',
    priceEstimate: 95,
    description: 'Estudio de marca ilustrada con un cuervo en un marco circular místico con siluetas de castillos góticos medievales y luna de fondo.',
    imageSrc: COMPONENT_LOGOS_GRID,
    crop: {
      isCropped: true,
      scale: 'w-[200%] h-[200%]',
      position: 'top-0 left-0'
    },
    features: [
      'Isologo circular ideal para sellos, stickers o empaque',
      'Ilustración artesanal de cuervo grabada detalladamente',
      'Fuentes tipográficas exclusivas estilizadas',
      'Entregables en formatos PNG translúcido, SVG (Vectorial) y PDF'
    ]
  },
  {
    id: 'l-2',
    title: 'Logo Dolce Fiore Pastelería',
    category: 'logos-branding',
    styleTag: 'Logotipo Vintage Acuarela',
    priceEstimate: 85,
    description: 'Diseño de logotipo para pastelería artesanal o cafetería acogedora. Ilustración de pastel de fresas con detalles florales circulares y caligrafía romántica.',
    imageSrc: COMPONENT_LOGOS_GRID,
    crop: {
      isCropped: true,
      scale: 'w-[200%] h-[200%]',
      position: 'top-0 left-[-100%]'
    },
    features: [
      'Estilo ilustrado vintage tierno en colores pastel cálidos',
      'Logotipo óptimo para marcas de alimentos y repostería',
      'Identidad visual adaptable a redes y cajas de productos',
      'Incluye paleta cromática de referencia para interiores'
    ]
  },
  {
    id: 'l-3',
    title: 'Logo Draxion Esports',
    category: 'logos-branding',
    styleTag: 'Esports Mascot / Cyber',
    priceEstimate: 110,
    description: 'Escudo emblemático gaming de alta impacto con dragón negro cibernético, reflejos de energía neón azul y tipografía agresiva tridimensional de metal cepillado.',
    imageSrc: COMPONENT_LOGOS_GRID,
    crop: {
      isCropped: true,
      scale: 'w-[200%] h-[200%]',
      position: 'top-[-100%] left-[-50%]'
    },
    features: [
      'Logotipo tipo "Mascot Logo" de alto impacto para equipos',
      'Ilustración vectorial simétrica con sombras de energía',
      'Letras con efecto metálico 3D totalmente personalizadas',
      'Entrega de variantes de color simplificadas para uniformes'
    ]
  }
];

export const STYLE_CATEGORIES = [
  { id: 'all', label: 'Todos los Estilos' },
  { id: 'color-illustrations', label: 'Ilustraciones a Color' },
  { id: 'manga-ink', label: 'Bocetos y Manga (B&N)' },
  { id: 'banners', label: 'Banners y Redes' },
  { id: 'logos-branding', label: 'Marcas y Logotipos' }
];

export const VISUAL_ESTILOS_INFO = [
  {
    name: 'Gótico / Cyberpunk',
    desc: 'Uso magistral del color violeta y carmesí, luces de faroles, sombras misteriosas, castillos medievales, tatuajes detallados y joyas sombrías.',
    accent: 'from-fuchsia-600 to-purple-800'
  },
  {
    name: 'Esports / Gaming',
    desc: 'Ilustración vectorial agresiva y de alto impacto, luces de energía cian/azul neón, escudos deportivos y dragones y animales cibernéticos en 3D.',
    accent: 'from-blue-600 to-indigo-900'
  },
  {
    name: 'Kawaii / Sweet Pastel',
    desc: 'Trazos suaves retro, pasteles de fresas, caligrafía romántica, tonos rosados acogedores y miradas anime tiernas que inspiran felicidad.',
    accent: 'from-rose-400 to-pink-500'
  },
  {
    name: 'Manga / Noir Line-art',
    desc: 'Tinta negra digital ultra fluida y purista, tramas degradadas, diagramación en paneles interactivos de manga japonés con globos de diálogos cinéticos.',
    accent: 'from-zinc-700 to-black'
  }
];

export const ARTIST_MISION = {
  title: 'Camila - Aura & Diseño',
  sub: 'Transformando conceptos abstractos en piezas visuales icónicas.',
  whatsapp: '3043520732',
  email: 'camidue21@gmail.com',
  location: 'Bogotá, Colombia',
  deliveryTime: '5-12 días hábiles dependiendo del pedido',
  paymentMethods: 'Nequi, Daviplata, Bancolombia, PayPal'
};
