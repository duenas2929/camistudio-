import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Portfolio from './components/Portfolio';
import VisualEstilos from './components/VisualEstilos';
import OrderForm from './components/OrderForm';
import Footer from './components/Footer';
import ItemModal from './components/ItemModal';
import { PortfolioItem, CategoryType } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState('inicio');
  const [selectedProduct, setSelectedProduct] = useState<PortfolioItem | null>(null);
  const [selectedCategoryForQuote, setSelectedCategoryForQuote] = useState<CategoryType>('color-illustrations');

  // Monitor active scroll section for header highlighting
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['inicio', 'portafolio', 'estilos', 'cotizar', 'contacto'];
      const scrollPosition = window.scrollY + 180; // offset for triggers

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handler to scroll to quote section and automatically select the category
  const handleScrollToQuoteWithCategory = (category: CategoryType) => {
    setSelectedCategoryForQuote(category);
    const orderSection = document.getElementById('cotizar');
    if (orderSection) {
      orderSection.scrollIntoView({ behavior: 'smooth' });
    }
    setActiveSection('cotizar');
  };

  const handleScrollToQuoteDefault = () => {
    const orderSection = document.getElementById('cotizar');
    if (orderSection) {
      orderSection.scrollIntoView({ behavior: 'smooth' });
    }
    setActiveSection('cotizar');
  };

  const handleScrollToPortfolio = () => {
    const portfolioSection = document.getElementById('portafolio');
    if (portfolioSection) {
      portfolioSection.scrollIntoView({ behavior: 'smooth' });
    }
    setActiveSection('portafolio');
  };

  // Handler from detail modal to load base item preferences directly to form
  const handleQuoteThisItemFormat = (item: PortfolioItem) => {
    handleScrollToQuoteWithCategory(item.category);
  };

  return (
    <div className="bg-[#fafafa] min-h-screen text-slate-900 selection:bg-slate-900 selection:text-white">
      {/* Dynamic Header */}
      <Header onNavigate={setActiveSection} activeSection={activeSection} />

      {/* Hero / Intro section */}
      <Hero
        onScrollToPortfolio={handleScrollToPortfolio}
        onScrollToQuote={handleScrollToQuoteDefault}
      />

      {/* Grid Portfolio of items */}
      <Portfolio
        onSelectProduct={setSelectedProduct}
        onScrollToQuoteWithService={handleScrollToQuoteWithCategory}
      />

      {/* Categorized visual styles section */}
      <VisualEstilos />

      {/* Interactive Quotation Form Calculator */}
      <OrderForm initialService={selectedCategoryForQuote} />

      {/* Footer and contact information */}
      <Footer onNavigate={setActiveSection} />

      {/* Lightbox details modal overlay */}
      <ItemModal
        item={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onQuoteThisItem={handleQuoteThisItemFormat}
      />
    </div>
  );
}
