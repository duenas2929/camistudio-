import { useState, useEffect } from 'react';
import { Phone, Mail, Sparkles, AlertCircle, Copy, CheckCircle } from 'lucide-react';
import { ARTIST_MISION } from '../data';
import { CategoryType } from '../types';

interface OrderFormProps {
  initialService?: CategoryType;
}

export default function OrderForm({ initialService = 'color-illustrations' }: OrderFormProps) {
  // Config state
  const [service, setService] = useState<CategoryType>(initialService);
  const [optionType, setOptionType] = useState<string>('');
  const [complexity, setComplexity] = useState<'simple' | 'medium' | 'detailed'>('medium');
  const [extras, setExtras] = useState<{
    sourceFiles: boolean;
    commercialRights: boolean;
    rushDelivery: boolean;
  }>({
    sourceFiles: false,
    commercialRights: false,
    rushDelivery: false
  });
  const [characterDetails, setCharacterDetails] = useState('');
  const [clientName, setClientName] = useState('');
  const [copiedText, setCopiedText] = useState(false);

  // Sync category initial selections when selected from portfolio
  useEffect(() => {
    setService(initialService);
    // Set default option sub-types for each category
    if (initialService === 'color-illustrations') {
      setOptionType('retrato');
    } else if (initialService === 'manga-ink') {
      setOptionType('lineart');
    } else if (initialService === 'banners') {
      setOptionType('standard');
    } else if (initialService === 'logos-branding') {
      setOptionType('isologo');
    }
  }, [initialService]);

  // Pricing matrix
  const getBasePrice = () => {
    if (service === 'color-illustrations') {
      if (optionType === 'retrato') return 45;
      if (optionType === 'mediocuerpo') return 75;
      return 120; // cuerpocompleto
    }
    if (service === 'manga-ink') {
      if (optionType === 'lineart') return 35;
      return 60; // paginamanga
    }
    if (service === 'banners') {
      return 40;
    }
    if (service === 'logos-branding') {
      if (optionType === 'isologo') return 95;
      if (optionType === 'vintage') return 85;
      return 110; // esports
    }
    return 45;
  };

  const getComplexityPrice = () => {
    if (complexity === 'simple') return 0;
    if (complexity === 'medium') return 15;
    return 35; // detailed
  };

  const getExtrasPrice = () => {
    let sum = 0;
    if (extras.sourceFiles) sum += 20;
    if (extras.commercialRights) sum += 50;
    if (extras.rushDelivery) sum += 30;
    return sum;
  };

  const totalPrice = getBasePrice() + getComplexityPrice() + getExtrasPrice();

  // Pre-formatted text summary
  const getSubTitleText = () => {
    if (service === 'color-illustrations') {
      if (optionType === 'retrato') return 'Retrato Ilustración Color (Busto/Avatar)';
      if (optionType === 'mediocuerpo') return 'Ilustración Color de Medio Cuerpo';
      return 'Ilustración Color de Cuerpo Completo con Fondo';
    }
    if (service === 'manga-ink') {
      if (optionType === 'lineart') return 'Tinta / Lineart de Sirvienta/Personaje';
      return 'Página Narrativa de Manga (Con Viñetas)';
    }
    if (service === 'banners') {
      return 'Banner Adaptativo para Streaming';
    }
    if (service === 'logos-branding') {
      if (optionType === 'isologo') return 'Isologo Ilustrado Circular';
      if (optionType === 'vintage') return 'Logotipo Acuarela Vintage';
      return 'Escudo Deportivo Especial Esports/Gaming';
    }
    return '';
  };

  // Prepares the final summary blocks for email or WhatsApp
  const generateMessageString = () => {
    return (
      `📝 *NUEVA COTIZACIÓN DE DISENO - CAMI STUDIO*\n` +
      `------------------------------------------\n` +
      `👤 *Cliente:* ${clientName || 'Invitado'}\n` +
      `🎨 *Servicio:* ${getSubTitleText()}\n` +
      `⚡ *Complejidad:* ${
        complexity === 'simple'
          ? 'Básico (Colores planos/Línea simple)'
          : complexity === 'medium'
          ? 'Estándar (Sombreado medio + texturas)'
          : 'Premium Detallado (Tratamiento avanzado + focos de luz)'
      }\n` +
      `➕ *Extras incluidos:*\n` +
      `   - Archivos fuente: ${extras.sourceFiles ? 'Sí (+$20 USD)' : 'No'}\n` +
      `   - Derechos comerciales: ${extras.commercialRights ? 'Sí (+$50 USD)' : 'No'}\n` +
      `   - Entrega rápida (Express): ${extras.rushDelivery ? 'Sí (+$30 USD)' : 'No'}\n` +
      `------------------------------------------\n` +
      `💬 *Detalles del Pedido:*\n` +
      `"${characterDetails || 'Sin detalles adicionales'}"\n` +
      `------------------------------------------\n` +
      `💵 *Total Estimado:* $${totalPrice} USD`
    );
  };

  const handleWhatsAppOrder = () => {
    const formattedText = encodeURIComponent(generateMessageString());
    window.open(`https://wa.me/57${ARTIST_MISION.whatsapp}?text=${formattedText}`, '_blank');
  };

  const handleEmailOrder = () => {
    const subject = encodeURIComponent(`Cotización de Diseño - ${clientName || 'Aura & Diseño'}`);
    const body = encodeURIComponent(generateMessageString());
    window.location.href = `mailto:${ARTIST_MISION.email}?subject=${subject}&body=${body}`;
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generateMessageString());
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  return (
    <section id="cotizar" className="py-24 bg-white relative border-b border-slate-100">
      <div className="absolute inset-x-0 top-0 h-px bg-slate-200" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Form controls */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xs">
            <div className="space-y-2">
              <h3 className="font-sans font-bold text-2xl text-slate-900">
                Calculadora & Pedido de Comisiones
              </h3>
              <p className="font-sans text-xs sm:text-sm text-slate-500">
                Selecciona tus opciones, detalla tu concepto y obtén un presupuesto preliminar instantáneo. Envía tu cotización directamente a Camila.
              </p>
            </div>

            {/* Step 1: Service selection */}
            <div className="space-y-3">
              <label className="font-sans text-xs font-bold text-slate-800 tracking-wider uppercase block">
                1. Selección de Servicio Principal
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'color-illustrations', label: 'Ilustración Color' },
                  { id: 'manga-ink', label: 'Manga / Tinta' },
                  { id: 'banners', label: 'Banners' },
                  { id: 'logos-branding', label: 'Marcas / Logos' }
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setService(item.id as CategoryType);
                      // Reset types values on switch
                      if (item.id === 'color-illustrations') {
                        setOptionType('retrato');
                      } else if (item.id === 'manga-ink') {
                        setOptionType('lineart');
                      } else if (item.id === 'banners') {
                        setOptionType('standard');
                      } else if (item.id === 'logos-branding') {
                        setOptionType('isologo');
                      }
                    }}
                    className={`p-3 rounded-xl border text-xs font-sans font-medium transition-all cursor-pointer ${
                      service === item.id
                        ? 'bg-slate-900 text-white border-slate-950 shadow-sm'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Service options */}
            <div className="space-y-3">
              <label className="font-sans text-xs font-bold text-slate-800 tracking-wider uppercase block">
                2. Formato y Enfoque del Proyecto
              </label>

              {/* Color style controls */}
              {service === 'color-illustrations' && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'retrato', label: 'Retrato (Cabeza / Busto)', desc: 'Ideal para fotos de perfil', price: 45 },
                    { id: 'mediocuerpo', label: 'Medio Cuerpo', desc: 'Personaje hasta la cintura', price: 75 },
                    { id: 'cuerpocompleto', label: 'Cuerpo Completo + Fondo', desc: 'Ilustración completa premium', price: 120 }
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => setOptionType(opt.id)}
                      className={`p-4 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer h-24 ${
                        optionType === opt.id
                          ? 'bg-slate-50 text-slate-900 border-slate-900 shadow-sm'
                          : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <span className="font-sans font-bold text-xs text-slate-900 block">{opt.label}</span>
                        <span className="font-sans text-[10px] text-slate-400 block leading-tight">{opt.desc}</span>
                      </div>
                      <span className="font-mono text-xs font-bold text-slate-800">${opt.price} USD</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Manga Ink options */}
              {service === 'manga-ink' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    { id: 'lineart', label: 'Arte de Línea Tradicional / Sirvientas', desc: 'Sola figura, tinta pura impecable', price: 35 },
                    { id: 'página', label: 'Página de Manga Profesional', desc: 'Hasta 5 paneles de guión narrativo', price: 60 }
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => setOptionType(opt.id)}
                      className={`p-4 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer h-24 ${
                        optionType === opt.id
                          ? 'bg-slate-50 text-slate-900 border-slate-900 shadow-sm'
                          : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <span className="font-sans font-bold text-xs text-slate-900 block">{opt.label}</span>
                        <span className="font-sans text-[10px] text-slate-400 block leading-tight">{opt.desc}</span>
                      </div>
                      <span className="font-mono text-xs font-bold text-slate-800">${opt.price} USD</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Banners options */}
              {service === 'banners' && (
                <div className="p-4 rounded-xl border border-slate-200 bg-[#fafafa] text-left flex items-center justify-between">
                  <div>
                    <span className="font-sans font-bold text-xs text-slate-900 block">Banner Adaptativo Redes</span>
                    <span className="font-sans text-[11px] text-slate-500 block max-w-sm">
                      Formato de encabezado pre-diseñado para Twitch, YouTube o Twitter con rejillas y tipografías editables.
                    </span>
                  </div>
                  <span className="font-mono text-sm font-bold text-slate-800 whitespace-nowrap">$40 USD</span>
                </div>
              )}

              {/* Logos & Marcas options */}
              {service === 'logos-branding' && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'isologo', label: 'Isologo Raven Gótico', desc: 'Sellos circulares para merch', price: 95 },
                    { id: 'vintage', label: 'Logotipo Vintage Acuarela', desc: 'Perfecto para reposterías/tiendas', price: 85 },
                    { id: 'esports', label: 'Escudo Deportivo Esports', desc: 'Dragones, mascotas, agresivo', price: 110 }
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => setOptionType(opt.id)}
                      className={`p-4 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer h-24 ${
                        optionType === opt.id
                          ? 'bg-slate-50 text-slate-900 border-slate-900 shadow-sm'
                          : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <span className="font-sans font-bold text-xs text-slate-900 block">{opt.label}</span>
                        <span className="font-sans text-[10px] text-slate-400 block leading-tight">{opt.desc}</span>
                      </div>
                      <span className="font-mono text-xs font-bold text-slate-800">${opt.price} USD</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Step 3: Complexity level */}
            <div className="space-y-3">
              <label className="font-sans text-xs font-bold text-slate-800 tracking-wider uppercase block">
                3. Complejidad del Render y Sombreado
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {[
                  { id: 'simple', label: 'Sombreado Plano (Cell-shade)', desc: 'Línea de contorno limpia y paleta de colores lisos.', price: 0 },
                  { id: 'medium', label: 'Sombreado Estándar Cami', desc: 'Degradados de color, reflejo de luz básico y pecas de pincel.', price: 15 },
                  { id: 'detailed', label: 'Sombreado Hiper-Focos', desc: 'Acabado de exposición. Doble luz indirecta de neón y texturas avanzadas.', price: 35 }
                ].map((level) => (
                  <button
                    key={level.id}
                    onClick={() => setComplexity(level.id as any)}
                    className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer h-24 ${
                      complexity === level.id
                        ? 'bg-slate-50 text-slate-900 border-slate-900 shadow-sm'
                        : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <span className="font-sans font-bold text-xs text-slate-900 block">{level.label}</span>
                      <span className="font-sans text-[9px] text-slate-400 leading-normal block line-clamp-2">{level.desc}</span>
                    </div>
                    <span className="font-mono text-xs font-bold text-slate-700">
                      {level.price === 0 ? 'Sin recargo' : `+$${level.price} USD`}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 4: Extras Add-ons */}
            <div className="space-y-3">
              <label className="font-sans text-xs font-bold text-slate-800 tracking-wider uppercase block">
                4. Atribuciones y Extras
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {/* Source files */}
                <button
                  onClick={() => setExtras({ ...extras, sourceFiles: !extras.sourceFiles })}
                  className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                    extras.sourceFiles
                      ? 'bg-slate-900 text-white border-slate-950 shadow-xs'
                      : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="truncate pr-2">
                    <span className="font-sans font-bold text-xs block">Archivos Fuente (.PSD/.SVG)</span>
                    <span className="font-sans text-[9px] text-slate-400 block">Capas editables originales</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-slate-705">+$20</span>
                </button>

                {/* Commercial license */}
                <button
                  onClick={() => setExtras({ ...extras, commercialRights: !extras.commercialRights })}
                  className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                    extras.commercialRights
                      ? 'bg-slate-900 text-white border-slate-950 shadow-xs'
                      : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="truncate pr-2">
                    <span className="font-sans font-bold text-xs block">Venta Comercial Total</span>
                    <span className="font-sans text-[9px] text-slate-400 block">Reventa y monetización libre</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-slate-705">+$50</span>
                </button>

                {/* rush package */}
                <button
                  onClick={() => setExtras({ ...extras, rushDelivery: !extras.rushDelivery })}
                  className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                    extras.rushDelivery
                      ? 'bg-slate-900 text-white border-slate-950 shadow-xs'
                      : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="truncate pr-2">
                    <span className="font-sans font-bold text-xs block">Entrega Express </span>
                    <span className="font-sans text-[9px] text-slate-400 block">Prioridad límite de 3 días</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-slate-705">+$30</span>
                </button>
              </div>
            </div>

            {/* Step 5: Details / Conceptual notes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="font-sans text-xs font-bold text-slate-800 tracking-wider uppercase block">
                  Tu Nombre o Identidad Virtual
                </label>
                <input
                  type="text"
                  placeholder="Ej: Akiza VTuber / Dolce Pastelería"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-400 transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="font-sans text-xs font-bold text-slate-800 tracking-wider uppercase block">
                  Instrucciones y Referencias Visuales
                </label>
                <textarea
                  rows={2}
                  placeholder="Ej: Cabello oscuro con trenzas, ropa cyberpunk violeta..."
                  value={characterDetails}
                  onChange={(e) => setCharacterDetails(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-400 transition-colors resize-y min-h-[46px]"
                />
              </div>
            </div>
            
          </div>

          {/* Right Live Summary box */}
          <div className="lg:col-span-12 lg:col-span-5 space-y-6">
            <div className="bg-[#fafafa] border border-slate-200 rounded-2xl p-6 sm:p-8 relative shadow-sm overflow-hidden self-start">
              {/* Top ambient glare */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-slate-200/40 blur-[40px] pointer-events-none" />

              <div className="flex items-center gap-2 mb-6">
                <Sparkles className="w-5 h-5 text-slate-805" />
                <span className="font-sans font-bold text-sm text-slate-800 uppercase tracking-widest block">
                  Presupuesto en Tiempo Real
                </span>
              </div>

              {/* Price display layout */}
              <div className="py-6 border-b border-slate-200 text-center space-y-2">
                <span className="font-mono text-[10px] text-slate-400 uppercase tracking-widest block">
                  VALOR DE COTIZACIÓN ESTIMADA
                </span>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="font-sans font-extrabold text-5xl text-slate-900">
                    ${totalPrice}
                  </span>
                  <span className="font-mono text-sm text-slate-600 font-bold">
                    USD
                  </span>
                </div>
                <p className="font-sans text-[10.5px] text-slate-400">
                  Calculado en base a tarifas standard de Cami. No incluye impuestos locales.
                </p>
              </div>

              {/* Dynamic review ledger */}
              <div className="py-4 space-y-3.5 text-xs font-sans">
                <h4 className="font-bold text-slate-900">Resumen Técnico de Atributos:</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-slate-600">
                    <span>Base: {getSubTitleText()}</span>
                    <span className="font-mono font-bold text-slate-900">${getBasePrice()} USD</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-600">
                    <span>Tratamiento de Sombreado:</span>
                    <span className="font-mono font-bold text-slate-900">+${getComplexityPrice()} USD</span>
                  </div>
                  {extras.sourceFiles && (
                    <div className="flex items-center justify-between text-slate-800 font-semibold">
                      <span>✓ Archivos fuente listos editables</span>
                      <span className="font-mono font-bold">+$20 USD</span>
                    </div>
                  )}
                  {extras.commercialRights && (
                    <div className="flex items-center justify-between text-slate-800 font-semibold">
                      <span>✓ Derechos comerciales completos</span>
                      <span className="font-mono font-bold">+$50 USD</span>
                    </div>
                  )}
                  {extras.rushDelivery && (
                    <div className="flex items-center justify-between text-slate-800 font-semibold">
                      <span>⚡ Entrega Express en 3 días</span>
                      <span className="font-mono font-bold">+$30 USD</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Actions details block */}
              <div className="pt-6 border-t border-slate-200 space-y-3">
                <div className="flex gap-2">
                  <button
                    id="order-btn-whatsapp"
                    onClick={handleWhatsAppOrder}
                    className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-bold text-sm tracking-wide transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                  >
                    <Phone className="w-4 h-4" />
                    Enviar a WhatsApp
                  </button>
                  <button
                    id="order-btn-email"
                    onClick={handleEmailOrder}
                    className="py-3 px-4 rounded-xl bg-white hover:bg-slate-50 border border-slate-250 text-slate-700 hover:text-slate-950 font-sans font-bold text-sm transition-colors flex items-center justify-center cursor-pointer"
                    title="Enviar por Correo"
                  >
                    <Mail className="w-4 h-4" />
                  </button>
                </div>

                <button
                  id="order-btn-copy"
                  onClick={copyToClipboard}
                  className="w-full py-2.5 rounded-xl border border-dashed border-slate-200 text-slate-500 hover:text-slate-900 hover:border-slate-400 bg-transparent text-xs font-mono transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {copiedText ? (
                    <>
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                      ¡Copiado al portapapeles!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copiar resumen de especificaciones
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Note regarding workflow */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 flex gap-3 text-xs font-sans text-slate-500 leading-normal">
              <AlertCircle className="w-5 h-5 text-slate-405 shrink-0" />
              <div>
                <span className="font-bold text-slate-800 block mb-0.5">¿Qué sucede al enviar?</span>
                Tu configuración se convertirá en un mensaje preparado con esmero. Camila revisará la complejidad en menos de 24 horas para dar consentimiento del boceto inicial, acordar el método de abono y fijar la fecha puntual en el cronograma.
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
