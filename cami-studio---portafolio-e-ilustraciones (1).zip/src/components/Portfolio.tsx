import { useState } from 'react';
import { Eye, DollarSign, Sparkles, Filter, CheckCircle2 } from 'lucide-react';
import { PORTFOLIO_ITEMS, STYLE_CATEGORIES } from '../data';
import { PortfolioItem, CategoryType } from '../types';

interface PortfolioProps {
  onSelectProduct: (item: PortfolioItem) => void;
  onScrollToQuoteWithService: (service: CategoryType) => void;
}

export default function Portfolio({ onSelectProduct, onScrollToQuoteWithService }: PortfolioProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredItems = selectedCategory === 'all'
    ? PORTFOLIO_ITEMS
    : PORTFOLIO_ITEMS.filter(item => item.category === selectedCategory);

  return (
    <section id="portafolio" className="py-24 bg-white relative border-b border-slate-100">
      <div className="absolute inset-x-0 top-0 h-px bg-slate-200" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 font-mono text-xs text-slate-800">
            <Filter className="w-3.5 h-3.5" />
            Catálogo de Servicios
          </div>
          <h2 className="font-sans text-3xl sm:text-4xl font-extrabold text-slate-900">
            Portafolio de Creaciones
          </h2>
          <p className="font-sans text-sm sm:text-base text-slate-500 max-w-xl mx-auto">
            Explora las piezas individuales filtradas por estilo. Haz clic en cualquiera para ver su ficha técnica detallada.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {STYLE_CATEGORIES.map((tab) => (
            <button
              key={tab.id}
              id={`tab-${tab.id}`}
              onClick={() => setSelectedCategory(tab.id)}
              className={`px-4 py-2.5 rounded-xl border text-xs sm:text-sm font-sans font-medium tracking-wide transition-all duration-300 cursor-pointer ${
                selectedCategory === tab.id
                  ? 'bg-slate-900 text-white border-slate-950 shadow-sm'
                  : 'bg-white text-slate-650 border-slate-200 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Grid layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredItems.map((item) => {
            return (
              <div
                key={item.id}
                id={`portfolio-card-${item.id}`}
                onClick={() => onSelectProduct(item)}
                className="group relative overflow-hidden rounded-2xl border border-slate-200 bg-white cursor-pointer flex flex-col transition-all duration-300 hover:border-slate-400 hover:shadow-md hover:-translate-y-1"
              >
                {/* Visual Frame wrapper containing potentially cropped images */}
                <div className="relative w-full aspect-square overflow-hidden bg-slate-50 rounded-t-2xl">
                  {/* Outer scale wrap to maintain crop coordinates smoothly during zoom */}
                  <div className="w-full h-full transform transition-transform duration-700 ease-out group-hover:scale-105">
                    {item.crop ? (
                      <img
                        src={item.imageSrc}
                        alt={item.title}
                        className={`absolute max-w-none ${item.crop.scale} ${item.crop.position}`}
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <img
                        src={item.imageSrc}
                        alt={item.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    )}
                  </div>

                  {/* Gradient bottom overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/20 via-transparent to-transparent opacity-80" />

                  {/* Hover Eye Trigger overlay */}
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="px-4 py-2 bg-white/95 backdrop-blur-md rounded-xl border border-slate-200 flex items-center gap-1.5 text-xs text-slate-800 font-semibold transform translate-y-3 group-hover:translate-y-0 transition-transform duration-300 shadow-sm">
                      <Eye className="w-3.5 h-3.5" />
                      Ficha de Arte
                    </div>
                  </div>

                  {/* Top-Right Style Badge */}
                  <div className="absolute top-3 right-3">
                    <span className="px-2 py-1 rounded bg-white/90 border border-slate-200 text-[10px] font-mono font-bold text-slate-750">
                      {item.styleTag}
                    </span>
                  </div>
                </div>

                {/* Info Text Area */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div className="space-y-2">
                    <h3 className="font-sans font-bold text-base text-slate-900 group-hover:text-slate-755 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="font-sans text-xs text-slate-500 leading-relaxed line-clamp-2">
                      {item.description}
                    </p>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="font-mono text-[9px] text-slate-400 uppercase block tracking-wider">
                        Rango Cotización
                      </span>
                      <span className="font-mono text-sm font-bold text-slate-900 flex items-center mt-0.5">
                        <DollarSign className="w-3.5 h-3.5 text-slate-500" />
                        {item.priceEstimate} USD
                      </span>
                    </div>

                    <button
                      id={`quote-btn-${item.id}`}
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent modal opening
                        onScrollToQuoteWithService(item.category);
                      }}
                      className="px-3 py-1.5 rounded-full border border-slate-200 bg-white hover:bg-slate-50 text-slate-805 text-xs font-semibold cursor-pointer transition-colors shadow-xs"
                    >
                      Cotizar
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
      </div>
    </section>
  );
}
