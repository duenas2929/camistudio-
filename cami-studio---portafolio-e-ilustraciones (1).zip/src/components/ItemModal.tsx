import { X, Check, DollarSign, HelpCircle, ArrowRight } from 'lucide-react';
import { PortfolioItem } from '../types';

interface ItemModalProps {
  item: PortfolioItem | null;
  onClose: () => void;
  onQuoteThisItem: (item: PortfolioItem) => void;
}

export default function ItemModal({ item, onClose, onQuoteThisItem }: ItemModalProps) {
  if (!item) return null;

  return (
    <div
      id="item-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md overflow-y-auto animate-fade-in"
      onClick={onClose}
    >
      <div
        id="item-modal-content"
        className="relative w-full max-w-4xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden my-8 cursor-default flex flex-col md:flex-row max-h-[90vh] md:max-h-none h-auto md:h-initial"
        onClick={(e) => e.stopPropagation()} // Prevent closing when interacting inside
      >
        {/* Close Button top-right corner */}
        <button
          id="item-modal-close"
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white border border-slate-200 text-slate-400 hover:text-slate-800 transition-colors shadow-xs cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Column 1: Massive Image Crop View */}
        <div className="w-full md:w-1/2 aspect-square md:aspect-auto md:h-[550px] relative overflow-hidden bg-slate-50 flex items-center justify-center shrink-0 border-r border-slate-100">
          <div className="w-full h-full">
            {item.crop ? (
              <div className="w-full h-full relative overflow-hidden">
                <img
                  src={item.imageSrc}
                  alt={item.title}
                  className={`absolute max-w-none ${item.crop.scale} ${item.crop.position}`}
                  referrerPolicy="no-referrer"
                />
              </div>
            ) : (
              <img
                src={item.imageSrc}
                alt={item.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            )}
          </div>
          {/* Subtle gradient shadow block */}
          <div className="absolute inset-0 bg-gradient-to-t from-white via-white/10 to-transparent pointer-events-none md:hidden" />
        </div>

        {/* Column 2: Content details description & quote triggers */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[50vh] md:max-h-[550px]">
          <div className="space-y-6">
            {/* Category tag & price block */}
            <div className="flex items-center justify-between pt-4 md:pt-0">
              <span className="px-3 py-1 rounded bg-slate-100 border border-slate-200 text-xs font-mono font-semibold tracking-wide text-slate-800">
                {item.styleTag}
              </span>
              <div className="flex items-center font-mono font-bold text-base text-slate-900 bg-slate-50 px-3 py-1 rounded-lg border border-slate-200">
                <DollarSign className="w-3.5 h-3.5" />
                <span>{item.priceEstimate} USD</span>
              </div>
            </div>

            {/* Title and descriptions */}
            <div className="space-y-3">
              <h3 className="font-sans font-bold text-2xl text-slate-900 tracking-tight">
                {item.title}
              </h3>
              <p className="font-sans text-sm text-slate-500 leading-relaxed">
                {item.description}
              </p>
            </div>

            {/* Feature lists checklist */}
            <div className="space-y-3">
              <h4 className="font-sans font-bold text-xs text-slate-800 uppercase tracking-widest block">
                ATRIBUTOS DE ENTREGABLE INCLUIDOS:
              </h4>
              <ul className="grid grid-cols-1 gap-2">
                {item.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 leading-tight">
                    <div className="p-0.5 rounded bg-slate-100 border border-slate-200 text-slate-800 shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Bottom order/quote CTAs */}
          <div className="pt-6 border-t border-slate-100 mt-6 space-y-4">
            <button
              id="modal-cta-quote"
              onClick={() => {
                onQuoteThisItem(item);
                onClose();
              }}
              className="w-full py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-sans font-bold text-sm shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              Seleccionar este Formato para Mi Cotizador
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="flex items-center justify-center gap-1.5 text-[10px] font-mono text-slate-400 text-center">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Esto cargará los parámetros base de ({item.title}) en la calculadora</span>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}
