import { Mail, Phone, MapPin, Palette, Heart, CheckCircle2 } from 'lucide-react';
import { ARTIST_MISION } from '../data';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const handleLinkClick = (id: string) => {
    onNavigate(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer id="contacto" className="bg-slate-50 border-t border-slate-200 pt-16 pb-8 relative overflow-hidden">
      {/* Subtle bottom gradients */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3/4 h-1/4 bg-slate-205/30 blur-[80px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          
          {/* Column 1: Bios & Brands */}
          <div className="md:col-span-5 space-y-4 text-left">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center">
                <Palette className="w-4 h-4 text-white" />
              </div>
              <span className="font-sans font-bold text-base text-slate-900 tracking-widest block uppercase">
                CAMI STUDIO
              </span>
            </div>
            <p className="font-sans text-xs sm:text-sm text-slate-500 max-w-sm leading-relaxed">
              Estudio de diseño digital e ilustración mística por Camila. Creando retratos ciber-góticos, renders a color cinemáticos, mangas tradicionales a tinta, banners de streaming y logotipos corporativos estilizados.
            </p>
            <div className="pt-2 flex flex-wrap gap-2">
              {['Nequi', 'Daviplata', 'Bancolombia', 'PayPal'].map((p) => (
                <span key={p} className="px-2 py-0.5 rounded bg-white border border-slate-200 text-[9px] font-mono text-slate-555 font-bold uppercase tracking-wider">
                  {p}
                </span>
              ))}
            </div>
          </div>

          {/* Column 2: Direct Contact Pillars */}
          <div className="md:col-span-4 space-y-4 text-left">
            <h4 className="font-sans font-bold text-xs text-slate-800 uppercase tracking-widest block">
              Canales Directos de Camila
            </h4>
            
            <div className="space-y-3 font-sans text-xs sm:text-sm text-slate-500">
              <a
                id="footer-contact-whatsapp"
                href={`https://wa.me/57${ARTIST_MISION.whatsapp}?text=Hola%20Camila,%20estoy%20en%20tu%20sitio%20web%20y%20me%20gustar%C3%ADa%20cotizar%20un%20dise%C3%B1o.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 py-1.5 px-3 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-350 transition-all cursor-pointer group"
              >
                <Phone className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform shrink-0" />
                <div className="truncate">
                  <span className="font-mono text-[9px] text-slate-400 block uppercase tracking-wider">WHATSAPP</span>
                  <span className="text-slate-855 font-semibold">(+57) 304 352 0732</span>
                </div>
              </a>

              <a
                id="footer-contact-email"
                href={`mailto:${ARTIST_MISION.email}?subject=Cotización%20Proyecto%20de%20Arte`}
                className="flex items-center gap-3 py-1.5 px-3 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-350 transition-all cursor-pointer group"
              >
                <Mail className="w-4 h-4 text-slate-800 group-hover:scale-110 transition-transform shrink-0" />
                <div className="truncate">
                  <span className="font-mono text-[9px] text-slate-400 block uppercase tracking-wider">EMAIL DE CONTACTO</span>
                  <span className="text-slate-855 font-semibold">{ARTIST_MISION.email}</span>
                </div>
              </a>

              <div className="flex items-center gap-3 py-1.5 px-3 rounded-lg bg-transparent border border-transparent">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                <div>
                  <span className="font-mono text-[9px] text-slate-400 block uppercase tracking-wider">UBICACIÓN</span>
                  <span className="text-slate-555 font-medium">{ARTIST_MISION.location}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Column 3: Navigation Quick Links */}
          <div className="md:col-span-3 space-y-4 text-left">
            <h4 className="font-sans font-bold text-xs text-slate-800 uppercase tracking-widest block">
              Explorar
            </h4>
            <div className="flex flex-col gap-2 font-sans text-xs">
              {[
                { label: 'Ir al Inicio', id: 'inicio' },
                { label: 'Portafolio de Diseños', id: 'portafolio' },
                { label: 'Estilos Visuales Criaturas/Aura', id: 'estilos' },
                { label: 'Calculadora de Comisiones', id: 'cotizar' }
              ].map((link) => (
                <button
                  key={link.id}
                  id={`footer-nav-${link.id}`}
                  onClick={() => handleLinkClick(link.id)}
                  className="text-left text-slate-500 hover:text-slate-900 py-1 transition-colors cursor-pointer animate-fade-in"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Credits line */}
        <div className="pt-8 border-t border-slate-205 flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-[10px] text-slate-400">
          <div className="flex items-center gap-1">
            <span>© {new Date().getFullYear()} Cami Studio. Todos los derechos reservados.</span>
          </div>
          <div className="flex items-center gap-1 text-slate-400">
            <span>Hecho con</span>
            <Heart className="w-3 h-3 text-slate-900 fill-slate-900" />
            <span>&</span>
            <Palette className="w-3 h-3 text-slate-600" />
            <span>para el mundo del Arte Digital.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
