import { useState, useEffect } from 'react';
import { ArrowUpRight, Palette, Phone, Mail, Menu, X } from 'lucide-react';
import { ARTIST_MISION } from '../data';

interface HeaderProps {
  onNavigate: (sectionId: string) => void;
  activeSection: string;
}

export default function Header({ onNavigate, activeSection }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Inicio', id: 'inicio' },
    { label: 'Portafolio', id: 'portafolio' },
    { label: 'Estilos', id: 'estilos' },
    { label: 'Cotizar', id: 'cotizar' },
    { label: 'Contacto', id: 'contacto' }
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md border-b border-slate-200/80 py-3 shadow-sm'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div
            id="header-logo"
            className="flex items-center gap-2 cursor-pointer group"
            onClick={() => handleLinkClick('inicio')}
          >
            <div className="relative w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center shadow-sm group-hover:bg-slate-800 transition-colors">
              <Palette className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-sans font-bold text-lg tracking-tight text-slate-950 group-hover:text-slate-750 transition-colors block leading-none">
                CAMI STUDIO
              </span>
              <span className="font-mono text-[9px] text-slate-500 tracking-widest block uppercase mt-0.5">
                Ilustración • Diseño
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8 text-sm">
            {navLinks.map((link) => (
              <button
                key={link.id}
                id={`nav-${link.id}`}
                onClick={() => handleLinkClick(link.id)}
                className={`font-sans tracking-wide hover:text-slate-950 transition-colors cursor-pointer relative py-1 ${
                  activeSection === link.id
                    ? 'text-slate-950 font-bold'
                    : 'text-slate-500'
                }`}
              >
                {link.label}
                {activeSection === link.id && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-slate-950 rounded-full" />
                )}
              </button>
            ))}
          </nav>

          {/* Action CTA Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <a
              id="header-cta-whatsapp"
              href={`https://wa.me/57${ARTIST_MISION.whatsapp}?text=Hola%20Camila,%20estoy%20en%20tu%20sitio%20web%20y%20me%20gustar%C3%ADa%20cotizar%20un%20dise%C3%B1o.`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#25D366] text-white text-xs font-semibold hover:bg-[#20ba59] shadow-sm transition-all duration-300"
            >
              <Phone className="w-3.5 h-3.5" />
              WhatsApp
            </a>
            <a
              id="header-cta-email"
              href={`mailto:${ARTIST_MISION.email}?subject=Cotización%20Proyecto%20de%20Arte`}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 shadow-sm transition-all duration-350"
            >
              <Mail className="w-3.5 h-3.5" />
              Email
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              id="mobile-menu-trigger"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-lg bg-white border border-slate-200 text-slate-500 hover:text-slate-800"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div id="mobile-menu-overlay" className="md:hidden bg-white border-b border-slate-200 px-4 py-6 shadow-lg absolute w-full left-0 top-full">
          <div className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <button
                key={link.id}
                id={`nav-mobile-${link.id}`}
                onClick={() => handleLinkClick(link.id)}
                className={`font-sans tracking-wide py-2 text-left text-base ${
                  activeSection === link.id
                    ? 'text-slate-950 font-bold pl-2 border-l-2 border-slate-900'
                    : 'text-slate-500 pl-2'
                }`}
              >
                {link.label}
              </button>
            ))}
            <hr className="border-slate-100 my-1" />
            <div className="grid grid-cols-2 gap-3 pt-2">
              <a
                id="mobile-nav-whatsapp"
                href={`https://wa.me/57${ARTIST_MISION.whatsapp}?text=Hola%20Camila,%20estoy%20en%20tu%20sitio%20web%20y%20me%20gustar%C3%ADa%20cotizar%20un%20dise%C3%B1o.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 rounded-full bg-[#25D366] text-white font-sans text-sm font-semibold"
              >
                <Phone className="w-4 h-4" />
                WhatsApp
              </a>
              <a
                id="mobile-nav-email"
                href={`mailto:${ARTIST_MISION.email}?subject=Cotización%20Proyecto%20de%20Arte`}
                className="flex items-center justify-center gap-2 py-2.5 rounded-full border border-slate-200 bg-white font-sans text-sm font-semibold text-slate-800"
              >
                <Mail className="w-4 h-4" />
                Email
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
