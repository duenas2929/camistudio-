import { ArrowDown, MessageSquare, Phone, Calendar, ShieldCheck, Sparkles } from 'lucide-react';
import { ARTIST_MISION, COMPONENT_FEATURED_ILLUST } from '../data';

interface HeroProps {
  onScrollToPortfolio: () => void;
  onScrollToQuote: () => void;
}

export default function Hero({ onScrollToPortfolio, onScrollToQuote }: HeroProps) {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center pt-28 pb-16 overflow-hidden bg-[#fafafa]">
      {/* Background Gradients */}
      <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-slate-200/50 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-slate-200/50 blur-[120px] pointer-events-none" />

      {/* Grid Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Text details */}
          <div className="lg:col-span-7 space-y-8 text-left">
            <div>
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-slate-200 backdrop-blur-sm mb-6 shadow-xs">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="font-mono text-[11px] font-bold tracking-wider text-slate-800 uppercase">
                  Comisiones Abiertas • 3 Cupos Libres
                </span>
              </div>

              <h1 className="font-sans text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.1]">
                Ilustraciones con{' '}
                <span className="text-slate-600 italic font-serif">
                  Alma Mística
                </span>{' '}
                e Identidades de Impacto
              </h1>
            </div>

            <p className="font-sans text-base sm:text-lg text-slate-600 max-w-2xl leading-relaxed">
              Hola, soy <strong>Camila</strong>. Creo ilustraciones digitales de alta gama, banners de streaming inmersivos y diseño de marcas y logotipos únicos. ¿Buscas arte a tinta tipo manga o mundos detallados a color? Estás en el lugar indicado.
            </p>

            {/* Quick Benefits Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-3 border-y border-slate-200">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-xs text-slate-900">Garantía Profesional</h4>
                  <p className="font-mono text-[10px] text-slate-500">Contratos, licencias y fuentes</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-xs text-slate-900">Fechas Cumplidas</h4>
                  <p className="font-mono text-[10px] text-slate-500">{ARTIST_MISION.deliveryTime}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-xs">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-xs text-slate-900">Arte a Tu Medida</h4>
                  <p className="font-mono text-[10px] text-slate-500">Manga, B&N y color RGB</p>
                </div>
              </div>
            </div>

            {/* Call to Action buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                id="hero-cta-quote"
                onClick={onScrollToQuote}
                className="px-6 py-3.5 rounded-xl bg-slate-900 text-white font-sans font-bold text-sm shadow-sm hover:bg-slate-800 active:scale-[0.98] transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4.5 h-4.5" />
                Cotizar Mi Diseño
              </button>
              <button
                id="hero-cta-portfolio"
                onClick={onScrollToPortfolio}
                className="px-6 py-3.5 rounded-xl border border-slate-200 bg-white text-slate-700 hover:text-slate-950 hover:bg-slate-50 font-sans text-sm font-semibold transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                Explorar Portafolio
                <ArrowDown className="w-4 h-4 animate-bounce" />
              </button>
            </div>

            {/* Quick social stats */}
            <div className="flex items-center gap-6 pt-3 text-xs text-slate-500 font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>WhatsApp: {ARTIST_MISION.whatsapp}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                <span>Email: {ARTIST_MISION.email}</span>
              </div>
            </div>
          </div>

          {/* Right Featured Illustration Design */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative group w-full max-w-[400px]">
              
              {/* Outer Glow Background */}
              <div className="absolute -inset-1 bg-slate-200 rounded-2xl blur-md opacity-30 group-hover:opacity-40 transition-all duration-1000" />
              
              {/* Decorative Frame */}
              <div className="relative bg-white border border-slate-200 rounded-2xl p-3 shadow-md overflow-hidden">
                <div className="relative aspect-[3/4] rounded-xl overflow-hidden bg-slate-55">
                  <img
                    id="hero-featured-image"
                    src={COMPONENT_FEATURED_ILLUST}
                    alt="Ilustración Destacada - Aura Gótica Camila"
                    className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-transparent pointer-events-none" />
                  
                  {/* Floating Overlay Badge */}
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-slate-900/90 backdrop-blur text-[10px] font-mono tracking-wider font-semibold text-white">
                    ILUSTRACIÓN PRINCIPAL
                  </div>

                  <div className="absolute bottom-3 left-3 right-3 p-3.5 rounded-lg bg-white/95 backdrop-blur border border-slate-200">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-sans font-bold text-xs text-slate-900">Aura Gótica Nocturna</span>
                      <span className="font-mono text-xs font-bold text-slate-700">Desde $120 USD</span>
                    </div>
                    <p className="font-sans text-[11px] text-slate-500 leading-normal line-clamp-2">
                      Fusión sublime de estilo manga moderno, arquitectura catedralicia y manejo místico de la iluminación.
                    </p>
                  </div>
                </div>
              </div>

              {/* Decorative abstract elements */}
              <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-slate-100/50 blur-md pointer-events-none" />
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-slate-100/50 blur-md pointer-events-none" />
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
