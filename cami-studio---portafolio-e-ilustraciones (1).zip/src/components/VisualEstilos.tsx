import { Paintbrush, Check, ChevronRight } from 'lucide-react';
import { VISUAL_ESTILOS_INFO } from '../data';

export default function VisualEstilos() {
  const customIcons = [
    { key: '0', icon: '💀' },
    { key: '1', icon: '🐉' },
    { key: '2', icon: '🌸' },
    { key: '3', icon: '✒️' }
  ];

  return (
    <section id="estilos" className="py-24 bg-[#fafafa] relative overflow-hidden border-b border-slate-100">
      {/* Background radial highlight */}
      <div className="absolute top-[30%] left-[50%] -translate-x-1/2 w-[60%] h-[30%] bg-slate-205/30 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section title */}
        <div className="text-center space-y-4 mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 font-mono text-xs text-slate-800">
            <Paintbrush className="w-3.5 h-3.5" />
            ADN Creativo
          </div>
          <h2 className="font-sans text-3xl sm:text-4xl font-extrabold text-slate-900">
            Estilos Visuales Especializados
          </h2>
          <p className="font-sans text-sm sm:text-base text-slate-500 max-w-xl mx-auto">
            Cada creación nace de una dirección artística rigurosa. Encuentra el estilo que resuena con tu identidad virtual o comercial.
          </p>
        </div>

        {/* Styles Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {VISUAL_ESTILOS_INFO.map((estilo, index) => {
            const iconObj = customIcons.find(i => i.key === index.toString());
            return (
              <div
                key={estilo.name}
                id={`estilo-card-${index}`}
                className="relative bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 hover:border-slate-350 hover:shadow-md group shadow-xs"
              >
                <div>
                  {/* Card head accent */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl filter drop-shadow">
                        {iconObj ? iconObj.icon : '🎨'}
                      </span>
                      <h3 className="font-sans font-bold text-xl text-slate-900 group-hover:text-slate-700 transition-colors">
                        {estilo.name}
                      </h3>
                    </div>
                    
                    {/* Visual bar gradient */}
                    <div className={`h-1.5 w-16 rounded-full bg-gradient-to-r ${estilo.accent}`} />
                  </div>

                  <p className="font-sans text-sm text-slate-655 leading-relaxed mb-6">
                    {estilo.desc}
                  </p>

                  {/* Bullet specifics depending on index */}
                  <ul className="space-y-2.5 mb-8">
                    {index === 0 && (
                      <>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Manejo Lumínico:</strong> Sombreado dinámico de doble foco e iluminación de farol.</span>
                        </li>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Ideal para:</strong> Streamers de terror, VTubers góticos, carátulas musicales oscuras.</span>
                        </li>
                      </>
                    )}
                    {index === 1 && (
                      <>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Manejo Lumínico:</strong> Efecto vector metálico 3D y resplandor de energía viva.</span>
                        </li>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Ideal para:</strong> Equipos de Esports profesionales, canales de gaming competitivos y ropa técnica.</span>
                        </li>
                      </>
                    )}
                    {index === 2 && (
                      <>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Manejo Lumínico:</strong> Degradados suaves, texturas mullidas y paletas turgentes dulces.</span>
                        </li>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Ideal para:</strong> Reposterías, papelerías creativas, marcas infantiles y avatares tiernos.</span>
                        </li>
                      </>
                    )}
                    {index === 3 && (
                      <>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Manejo Lumínico:</strong> Tramado manual de cómic e impresión tipográfica de manga tradicional.</span>
                        </li>
                        <li className="flex items-start gap-2.5 text-xs text-slate-705">
                          <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                          <span><strong>Ideal para:</strong> Creadores de historietas independientes, fanzines, novelas ligeras y tatuajes reales.</span>
                        </li>
                      </>
                    )}
                  </ul>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-mono text-slate-400">
                  <span>GARANTÍA DE ORIGINALIDAD</span>
                  <div className="flex items-center gap-1.5 text-slate-800 hover:text-slate-950 cursor-pointer font-sans font-semibold">
                    <span>Ver ejemplos</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
      </div>
    </section>
  );
}
